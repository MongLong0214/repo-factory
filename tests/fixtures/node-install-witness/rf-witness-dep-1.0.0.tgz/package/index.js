export const version = "1.0.0";
export const mark = (who) => `rf-witness-dep ${version} used by ${who}`;
